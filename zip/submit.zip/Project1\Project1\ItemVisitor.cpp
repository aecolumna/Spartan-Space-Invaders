/**
 * \file ItemVisitor.cpp
 *
 * \author Andres Columna
 */



#include "stdafx.h"
#include "ItemVisitor.h"


/**
 * Constructor
 */
CItemVisitor::CItemVisitor()
{
}



/**
 * Destructor
 */
CItemVisitor::~CItemVisitor()
{
}
